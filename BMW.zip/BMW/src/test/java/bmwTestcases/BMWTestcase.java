package bmwTestcases;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import bmwbaseclass.WrapperClass;
import bmwexcel.ExcelWrite;
import bmwpagesPOM.BMWPage;

public class BMWTestcase extends WrapperClass
{
	BMWPage bp;
	@BeforeTest
	public void startup()
	{
		launch_browser("https://www.bmw.in/en/");
	}

	
	@Test
	public void t1() throws  IOException
	{
		ExcelWrite ex=new ExcelWrite();
	bp=PageFactory.initElements(dr, BMWPage.class);
	bp.models();
	bp.sev();
	bp.seven_ser();
	bp.td();
	String s1=bp.top_sp();
	ex.write_excel(0,0,s1);
	int i=Integer.parseInt(s1);
	boolean b=false;
	if(i<500)
	{
		Assert.assertTrue(b,"Does not meet my requirements");
	}
	else
	{
		System.out.println("True");
	}
	}
	
	@AfterTest
	public void closeBrowser()
	{
		quit();
	}
}
