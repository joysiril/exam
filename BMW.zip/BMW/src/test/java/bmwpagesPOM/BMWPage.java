package bmwpagesPOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BMWPage
{
	public static WebDriver dr;

	@FindBy(xpath="/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[1]/div/div[1]/a")
	public WebElement model;

	@FindBy(xpath="/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[1]/div/nav/div/div/div[4]/a")
	public WebElement seven;

	@FindBy(xpath="//div[@class='cosy-image-wrapper tw-relative']")
	public WebElement mouseover;
	
	@FindBy(xpath="/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/a")
    public WebElement img;
	
	@FindBy(xpath="/html/body/div[5]/main/div[1]/div[5]/div/div/div/div/div/div[4]/nav/div/div[3]/a")
	public WebElement technical_data;

	@FindBy(xpath="/html/body/div[5]/main/div[1]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[2]/div/table/tbody/tr[1]/td[2]/div")
	public WebElement speed;

	public void models()
	{
    	model.click();
	}

	public void sev()
	{
	seven.click();
	}

	public void seven_ser() 
	{
	     mouseover.click();
	     img.click();
	}

	public void td()
	{
	technical_data.click();
	}

	public String top_sp()
	{
	String s=speed.getText();
	System.out.println(s);
	return s;
	}
}
