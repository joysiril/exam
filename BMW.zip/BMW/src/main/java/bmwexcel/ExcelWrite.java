package bmwexcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWrite 
{
	 File f=new File("C:\\845187\\BMW\\src\\test\\resouces\\Testdata\\bmw.xlsx");
	 
		public void write_excel(int r,int c,String s) throws IOException
		 {
			  FileInputStream fil = new FileInputStream(f);
			  XSSFWorkbook workbook = new XSSFWorkbook(fil);
			  XSSFSheet sheet=workbook.getSheet("Sheet1");
			  XSSFRow row =sheet.createRow(r);
			  XSSFCell cell=row.createCell(c);
			  FileOutputStream fos=new FileOutputStream(f);
			  cell.setCellValue(s);
			  workbook.write(fos);
		 }
}
