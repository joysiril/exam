package bmwbaseclass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WrapperClass 
{
	protected WebDriver dr;

	public void launch_browser(String url)
	{
	System.setProperty("webdriver.chrome.driver", "C:\\845187\\BMW_Project\\src\\test\\resources\\Driver\\chromedriver_v80.exe");
	dr=new ChromeDriver();
	dr.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	dr.get(url);
	
	}

	public void quit()
	{
	dr.close();
	}
}
