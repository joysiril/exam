package Step_definition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_cucumber {
	WebDriver dr;
	@Given("^Broweser is launched & login page displaying$")
	public void broweser_is_launched_login_page_displaying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		 dr=new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
	   
	}

	@When("^I complete action$")
	public void i_complete_action() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		dr.findElement(By.xpath("//input[@name='keywords']")).sendKeys("fish");
		dr.findElement(By.xpath("//input[@id='searchProducts']")).click();
		dr.findElement(By.xpath("//div[@id='Catalog'][1]//child::a[@href='/catalog/products/FI-SW-01'][1]")).click();
	   
	}

	@Then("^I validate the outcomes$")
	public void i_validate_the_outcomes() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//dr.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[3]/td[2]/a")).click();
		dr.findElement(By.xpath("//a[@href='/cart?add&itemId=EST-2']")).click();
		String s=dr.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody")).getText();
		System.out.println(s);
		dr.close();
	
		
	    
	}

}
