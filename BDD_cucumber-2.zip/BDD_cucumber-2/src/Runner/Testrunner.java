package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="Features",glue="Step_definition")
public class Testrunner extends  AbstractTestNGCucumberTests {
	
	

}
