package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class logindata {


	WebDriver dr;
	By user=By.xpath("//input[@name='username']");
	By password=By.xpath("//input[@name='password']");
	By log=By.xpath("//input[@id='login']");
	By login=By.xpath("//a[@href='/login']");
	public logindata(WebDriver dr) {
		this.dr=dr;
	}
	public void loginpage() {
		dr.findElement(login).click();
	}
	public void name(String na) {
		
		dr.findElement(user).sendKeys(na);
	}
	public void passwords(String paswd) {
		
		dr.findElement(password).sendKeys(paswd);
	}
	public void clicking() {
		dr.findElement(log).click();
	}
	
	public void loginmainfun(String name,String password) {
		this.loginpage();
		this.name(name);
		this.passwords(password);
		this.clicking();
	}
	
	
	
}
