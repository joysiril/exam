package library;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class utlities {

static  int count=1;
Logger log;
	
	WebDriver dr;
	public utlities(WebDriver dr) {
		this.dr=dr;
		log=Logger.getLogger("devpinoyLogger");
	}

	
	public void update_log(String pass) {
		
		log.debug(pass);
	}

	public void waits(WebDriver dr)
	{
	this.dr=dr;
	}

	public WebElement waitForElement(By locator,int timeout)
	{
	try {
	WebDriverWait wait=new WebDriverWait(dr,timeout);
	WebElement element=wait.until(
	ExpectedConditions.visibilityOfElementLocated(locator));

	System.out.println("Element Located");
	return element;
	}catch(Exception e) {
	System.out.println("Element Not Located" + e);

	}
	return null;

	}
	
	public WebElement ToBeclickable(By locator,int timeout)
	{
	try {
	WebDriverWait wait=new WebDriverWait(dr,timeout);
	WebElement element=wait.until(
	ExpectedConditions.elementToBeClickable(locator));

	System.out.println("Element Located");
	return element;
	}catch(Exception e) {
	System.out.println("Element Not Located" + e);

	}
	return null;

	}
	public void Screenshot() {
		
		String s="C:\\Users\\BLTuser.BLT0197\\Desktop\\Screenshot\\";
		String Filename=count+".png";
	File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
	File f2=new File(s+Filename);
	
	
		try {
			FileUtils.copyFile(f1,f2);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		count++;
	}
}
	

	

