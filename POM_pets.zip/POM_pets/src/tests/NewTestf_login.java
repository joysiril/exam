package tests;

import org.testng.annotations.Test;

import excelpackage.testloginexc;
import library.utlities;
import pages.logindata;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class NewTestf_login extends testloginexc {
	
	logindata lol;
	WebDriver dr;
	utlities scr;
	utlities util;
	
	
  @Test(dataProvider="logindata")
  public void login(String username,String password) {
	 
	 // System.out.println("logiworking");
	  util =new utlities(dr);
	  util.update_log("launching chrome");
	  System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
	   dr=new ChromeDriver();
	  dr.get("https://jpetstore.cfapps.io/login");
	  logindata lol=new logindata(dr);
	  lol.loginmainfun(username, password);

  }
 
  
  @BeforeClass
  public void beforeClass() {
	  
	  util =new utlities(dr);
	  util.update_log("getting excel data");
	  giri();
	  
	  
  }

  @DataProvider(name="logindata")
  public String[][] giri1()  {
	  
	return testdata;
  }
	  
  }

