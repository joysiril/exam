package tests;

import org.testng.annotations.Test;

import excelpackage.testloginexc;
import library.utlities;
import pages.logindata;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class NewTest_firefox extends testloginexc{
	WebDriver dr;
	logindata lol;
	utlities scr;
	utlities util;
  
  @BeforeClass
  public void beforeClass() {
	  util =new utlities(dr);
	  util.update_log("Reading excel firefox");
	  giri();
  }
  
  @Test(dataProvider="logindata")
  public void f(String username,String password) {
	  
	  util =new utlities(dr);
	  util.update_log("launching firefox");
	  
	  System.setProperty("Webdriver.gecko.Driver","geckodriver.exe");
	     dr=new FirefoxDriver();
	  dr.get("https://jpetstore.cfapps.io/login");
	  
	  lol=new logindata(dr);
	  lol.loginmainfun("babu", "babuharibabu");
  }
  
  @DataProvider(name="logindata")
  public String[][] giri1()  {
	  
	return testdata;
  }
@AfterMethod
public void screen() {
	scr=new utlities(dr);
	scr.Screenshot();
	dr.close();
}
}
