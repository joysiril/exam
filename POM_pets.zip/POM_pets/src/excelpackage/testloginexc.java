package excelpackage;


	
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;

	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	

	public class testloginexc {

	public static String[][] testdata=new String[2][2];
	public static int  r,c;


	public static void giri()
	{

	//System.out.println("giribabu");
	String filename="C:\\Users\\BLTuser.BLT0197\\Desktop\\selenium new\\giribabu.xlsx";
	String   Sheet="Sheet1";
	//System.out.println("babu");
	int r=1;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	for( r=0;r<=1;r++ )
	{
	XSSFRow row=sh.getRow(r);
	
	for(c=0;c<=1;c++)
	{
	// XSSFRow row=sh.getRow(r);
	XSSFCell cell1 =row.getCell(c);
	testdata[r][c] =cell1.getStringCellValue();
	System.out.println(testdata[r][c]);
	
	

	}


	}

	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}

	
	}

	



