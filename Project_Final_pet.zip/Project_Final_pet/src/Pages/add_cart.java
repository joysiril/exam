package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class add_cart {
WebDriver dr;
	public add_cart(WebDriver dr) {
		this.dr=dr;
		
	}
	public void add_product() {
		
		dr.findElement(By.xpath("//div[@id='Catalog'][1]//child::a[@href='/catalog/products/FI-SW-01'][1]")).click();
	}
}
