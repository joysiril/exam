package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class pages_class {
WebDriver dr;
	
	public pages_class(WebDriver dr) {
		
		this.dr=dr;
	}
	public void search() {
		dr.findElement(By.xpath("//input[@name='keywords']")).sendKeys("fish");
		dr.findElement(By.xpath("//input[@id='searchProducts']")).click();
		
	}
}
