package Testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Pages.add_cart;
import Pages.added;
import Pages.pages_class;
import login.login_class;

public class NewTest1 extends login_class {
	
	WebDriver dr;
  @Test(priority=1)
  public void f() {
	  
	  dr=pet_login();
  }
	  @Test(priority=3)
	  public void f1() {
		  pages_class pag=new pages_class(dr);
		  pag.search();
		  
	  }
	  @Test(priority=4)
	  public void f3() {
		  add_cart add=new add_cart(dr);
		  add.add_product();
	  }
	  @Test(priority=5)
	  public void f4() {
		  
		  added fin=new added(dr);
		  fin.adding();
	  }
  }

