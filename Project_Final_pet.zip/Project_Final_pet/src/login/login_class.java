package login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_class {
	
	public WebDriver pet_login() {
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
		return dr;
		
	}

}
